const bandsData = require("./bands");
//const userData = require("./users");

module.exports = {
    //users: userData,
    bands: bandsData
};
